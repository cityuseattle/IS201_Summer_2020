def make_shirt(size = 'large', message = 'I love python!'):
    
    
    print("\nI love python!" + size + "t-shirt.")
    print('message,"' + message + '"')

make_shirt()
make_shirt(size = 'large')
make_shirt(size = 'medium')
make_shirt(size = '2XL',message = 'Sriracha5')